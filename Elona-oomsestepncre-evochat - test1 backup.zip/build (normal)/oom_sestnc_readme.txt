Elona oom Ex Sukutu Edition STep Nasuko Customについて

●概要
Elona oom Ex Sukutu Edition Southtyris を改造したヴァリアントです。
Elona oom Ex Sukutu Edition Southtyris の20190921T版をベースに息抜きで開発しています。
予期せぬ不具合等が発生する可能性があります。導入は自己責任でお願いします。

このヴァリアントの系列は以下の通りになっています。
Elona 1.22
omake 20150620
omake_overhaul 20160417
omake_overhaul_modifyEx 20170306fix
omake_overhaul_modifyEx_Sukutu_Edition 20180517 fix2
omake_overhaul_modifyEx_Sukutu_Edition_Southtyris 20190921T
*このヴァリアント*

このヴァリアントに同梱しているReadme及びhistoryにはSESTepNCの情報しか載せていません。
そのためomake, omake_overhaul, oomEx, Sukutu Edition, Southtyrisの変更点については各自でそれぞれのヴァリアントのReadme, historyに目を通してください。
なおSukutu Editionに関しては現在配布が行われていないため、以下のサイトに更新内容の情報が乗っているためそちらをご確認ください。
http://elona-omakefamily-wiki.com/?cmd=read&page=oomSE%2Freadme

●導入方法
1.Elona oom Ex Sukutu Edition Southtyrisが動作する環境で一度oomSE_southtyris.exeを起動してください。（画像ファイルが展開されます、無くても同梱の代用素材で動くようには出来てますが導入を推奨します）

2.oomSE_southtyris.exeと同じディレクトリに、同梱してあるファイル/フォルダを全てコピーしてください。

3.もし、user/music/musiclist.txtが存在する場合は、最後の行から以下の文を付け足してください。（曲追加により定義が追加されています）
overwish.mid		mcOverwish
fairyzort_01.mid	mcFairyzort1
nc_race.mid		mcNcrace
nc_voidtown.mid		mcNcVoidTown
nc_secret.mid		mcNcSecretZone

4.もし、ooのアップデートで追加された職業を使用したい場合は別の場所に最新のooを導入し、dataフォルダに生成されたoo_class.csvをNCが導入されている環境のdataフォルダに導入してください。

動作に必要なファイルは以下の通りです。
・本家Elona1.22開発版一式
・omake_overhaul付属の.dllファイル
・omake_overhaul付属のuser\以下のカスタム系のファイル
・Elona oom Ex Sukutu Edition Southtyris にて追加された画像ファイル(無くても下記の使用素材で動くようには出来ていますが導入推奨）

●互換性について
SESTからNasuko Customへの移行については想定されていますが、その他の環境からのNasuko Customへの移行、また一度Nasuko Customにて保存したセーブデータの別ヴァリアントへの移行は想定しておらず、正常な動作を保証できません。
また、Nasuko Customは非常に多くの追加要素が含まれているため予期せぬ不具合等が発生する可能性があります。
そのためセーブデータの事前バックアップ及び定期的なバックアップを強く推奨します。

●カスタム要素の互換性について
親ヴァリアントの更新により、一部NPCやアイテムのIDが変わっている可能性があるため完全に同じカスタム要素が使用できるとは限りません。注意してください。
なお、他ヴァリアントでも使用したいがエラーが発生する可能性を回避したい場合はcgod,citem,cnpcは各項目の頭に"nc_"とつけることでNCのみで読み込む定義を作成することが可能です。
例:
aiActSub.	"408,410,459"
nc_aiActSub.	"538,538,539"
特殊行動を決める時、NCではnc_aiActSubが、その他の環境ではaiActSubが読み込まれます。
詳細は解説書を参考ください。

●同梱ファイル
oomsestep_nc.exe			本体
oom_sestnc_readme.txt			説明書。このファイル
oom_sestnc_history.txt			更新履歴
oom_sestnc_update.txt			アップデートに伴い、何を行えば良いかをまとめたファイル
oom_sestnc_todo.txt			今後のアップデート予定
sestnc.html				更新内容をまとめた解説書(日本語)
longint.dll				新規追加のプラグイン　blueleaf様作成
hspinet.dll				旧dllから更新 既存のdllを上書きしてください
ADDT.dll				SESTと同等のADDT.dll
\map					追加MAP同梱
\sound					追加BGM SE同梱
\user\graphic				カスタムアイテム画像機能サンプル同梱
     \god               		《ほろ酔いのドゥーレイン》同梱
					《汐路のセリア》同梱
					《牧畜のダイボニー》同梱
					宝の巫覡『クルーラ』同梱
     \macro             		マクロ機能サンプル同梱
\newctalksample				システムメッセージ置き換えサンプル同梱
\data					Exマニュアルデータ同梱
\help					日本語用helpファイルの中身

●使用素材

-グラフィック

ooからoomSEのバフアイコン(仮差し替え)			制作:Aoi_nasuko

新規バフアイコン(仮差し替え)				制作:Aoi_nasuko

イツパロトルのグラフィック(仮差し替え)			制作:Aoi_nasuko

願いの神のグラフィック(仮差し替え)			制作:Aoi_nasuko

ミニマップアイコン、ターゲット(仮差し替え)		制作:Aoi_nasuko

アニメーション29番(仮差し替え)				制作:Aoi_nasuko

魂の収穫のエフェクト(仮差し替え)			制作:Aoi_nasuko

ハーブ料理（ハーブティ）				制作:Aoi_nasuko

新規NPCのグラフィック					制作:Aoi_nasuko

oomSESTの素材の規約(https://discordapp.com/channels/444344677114839060/471289214563123201/471328295099695105)に従って以下の画像を内蔵しています(※1)
ソフトクリーム・パンナコッタ・失敗料理			制作：ソナリ様
パンケーキ・グラタン・ポタージュ			制作：みけきつね様
《汐路のセリア》のグラフィック				制作：マジかよ簡易量産型様
★《大海の錨》及び宝玉・下僕のグラフィック		制作：みけきつね様

-追加神

《汐路のセリア》設定ファイル				制作:Aoi_nasuko
英訳　　　　　　　　　　　　　　			制作:有志作成

《ほろ酔いのドゥーレイン》　　　			制作:Aoi_nasuko

《牧畜のダイボニー》					制作:Aoi_nasuko

宝の巫覡『クルーラ』					制作:Aoi_nasuko

-サウンド

警告音							制作:Aoi_nasuko

.midファイル						制作:Aoi_nasuko

-マップ

フェアリゾートの各種マップ				制作:Aoi_nasuko

クリップルタウンの各種マップ				制作:Aoi_nasuko

サウスティリスのサブクエスト及び一部の追加マップ	制作:Aoi_nasuko

サウスティリスのワールド及び街マップ			制作:山奥様

-プログラム

NCにて追加されたプログラム				作成:Aoi_nasuko

解説書の作成に現在以下のツールを使用しています
ひとりwiki http://www2u.biglobe.ne.jp/~MAS/soft.html#htwiki

●開発環境
言語	HSP3.51　C#

●お願い
このヴァリアントの情報を別所に載せたり、配信したりする行為は"禁止されていない場所"であれば許可しますが、住み分けをしっかりと行い他の人に迷惑がかからないように行ってください。
他ヴァリアントや原作との混同を避けるため、最低でもタグ付け等を用いてNCでプレイしていることがわかるように配慮していただけると幸いです。

●補足
(※1)以下、oomSEST配布サーバー内の素材の規約の引用

投稿者が規約を明記している場合はそれに従ってください。
特に規約など明記されていない場合、
・投稿された素材は、Elona、oomSEST、及び他のヴァリアントで誰でも自由に使用できるものとします。
・投稿された素材は、カスタム・ワールド、その他カスタムに関連した要素に利用することができるものとします。
・投稿された素材は、ゲームの用途に応じて自由に改変できるものとします。
・投稿された素材は、自由に二次配布できるものとします。
・投稿された素材は、商用利用することはできないものとします。
・oomSESTでのクレジットはDiscordのハンドルネームをそのまま用います。ハンドルネームと異なる名前をクレジットして欲しい場合はその旨を明記してください。
